/* 
* bluebank
*/

#ifndef _PANEL_T024F754_QVGA_SPI_CMD_H_
#define _PANEL_T024F754_QVGA_SPI_CMD_H_

/*---------------------------------------------------------------------------*/
/* HEADER files                                                              */
/*---------------------------------------------------------------------------*/
#include "panel.h" 

/*---------------------------------------------------------------------------*/
/* Panel configuration                                                       */
/*---------------------------------------------------------------------------*/
static struct panel_config t024f754_qvga_cmd_panel_data = {
	"qcom,mdss_spi_t024f754_qvga_cmd", "spi:0:", "qcom,mdss-spi-panel",
	10, 0, "DISPLAY_1", 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/*---------------------------------------------------------------------------*/
/* Panel resolution                                                          */
/*---------------------------------------------------------------------------*/
static struct panel_resolution t024f754_qvga_cmd_panel_res = {
	240, 320, 79, 59, 60, 0, 10, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/*---------------------------------------------------------------------------*/
/* Panel color information                                                   */
/*---------------------------------------------------------------------------*/
static struct color_info t024f754_qvga_cmd_color = {
	16, 0, 0xff, 0, 0, 0
};

/*---------------------------------------------------------------------------*/
/* Panel on/off command information                                          */
/*---------------------------------------------------------------------------*/
static char t024f754_qvga_cmd_on_cmd0[] = {0x11};
static char t024f754_qvga_cmd_on_cmd1[] = {0x36,0x00};
static char t024f754_qvga_cmd_on_cmd2[] = {0x3a,0x05};
static char t024f754_qvga_cmd_on_cmd3[] = {0x2A,0x00,0x00,0x00,0xEF};
static char t024f754_qvga_cmd_on_cmd4[] = {0x2B,0x00,0x00,0x01,0x3F};
static char t024f754_qvga_cmd_on_cmd5[] = {0xb2,0x0c,0x0c,0x00,0x33,0x33};
static char t024f754_qvga_cmd_on_cmd6[] = {0xb7,0x35};
static char t024f754_qvga_cmd_on_cmd7[] = {0xbb,0x36};
static char t024f754_qvga_cmd_on_cmd8[] = {0xc0,0x2c};
static char t024f754_qvga_cmd_on_cmd9[] = {0xc2,0x01};
static char t024f754_qvga_cmd_on_cmd10[] = {0xc3,0x0d};
static char t024f754_qvga_cmd_on_cmd11[] = {0xc4,0x20};
static char t024f754_qvga_cmd_on_cmd12[] = {0xc6,0x14};
static char t024f754_qvga_cmd_on_cmd13[] = {0xd0,0xa4,0xa1};
static char t024f754_qvga_cmd_on_cmd14[] = {0xe0,0xd0,0x00,0x05,0x0e,0x15,0x0d,0x37,0x43,0x47,0x09,0x15,0x12,0x16,0x19};
static char t024f754_qvga_cmd_on_cmd15[] = {0xe1,0xd0,0x00,0x05,0x0d,0x0c,0x06,0x2d,0x44,0x40,0x0e,0x1c,0x18,0x16,0x19};
static char t024f754_qvga_cmd_on_cmd16[] = {0x35,0x00};
static char t024f754_qvga_cmd_on_cmd17[] = {0x44,0x00,0x10};
static char t024f754_qvga_cmd_on_cmd18[] = {0x29};
static char t024f754_qvga_cmd_on_cmd19[] = {0x2c};

static struct mdss_spi_cmd t024f754_qvga_cmd_on_command[] = {
	{sizeof(t024f754_qvga_cmd_on_cmd0), t024f754_qvga_cmd_on_cmd0, 0x78, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd1), t024f754_qvga_cmd_on_cmd1, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd2), t024f754_qvga_cmd_on_cmd2, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd3), t024f754_qvga_cmd_on_cmd3, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd4), t024f754_qvga_cmd_on_cmd4, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd5), t024f754_qvga_cmd_on_cmd5, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd6), t024f754_qvga_cmd_on_cmd6, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd7), t024f754_qvga_cmd_on_cmd7, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd8), t024f754_qvga_cmd_on_cmd8, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd9), t024f754_qvga_cmd_on_cmd9, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd10), t024f754_qvga_cmd_on_cmd10, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd11), t024f754_qvga_cmd_on_cmd11, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd12), t024f754_qvga_cmd_on_cmd12, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd13), t024f754_qvga_cmd_on_cmd13, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd14), t024f754_qvga_cmd_on_cmd14, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd15), t024f754_qvga_cmd_on_cmd15, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd16), t024f754_qvga_cmd_on_cmd16, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd17), t024f754_qvga_cmd_on_cmd17, 0x00, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd18), t024f754_qvga_cmd_on_cmd18, 0x14, 0},
	{sizeof(t024f754_qvga_cmd_on_cmd19), t024f754_qvga_cmd_on_cmd19, 0x00, 0},
};

#define T024F754_QVGA_CMD_ON_COMMAND 20   //num_of_panel_cmds 1~19


static char t024f754_qvga_cmdoff_cmd0[] = {
	0x28,
};

static char t024f754_qvga_cmdoff_cmd1[] = {
	0x10,
};

static struct mipi_dsi_cmd t024f754_qvga_cmd_off_command[] = {
	{0x1, t024f754_qvga_cmdoff_cmd0, 0x20},
	{0x1, t024f754_qvga_cmdoff_cmd1, 0x20}
};

#define T024F754_QVGA_CMD_OFF_COMMAND 2

/*---------------------------------------------------------------------------*/
/* Panel reset sequence                                                      */
/*---------------------------------------------------------------------------*/
static struct panel_reset_sequence t024f754_qvga_cmd_reset_seq = {
	{1, 0, 1, }, {20, 2, 20, }, 2
};

/*---------------------------------------------------------------------------*/
/* Backlight setting                                                         */
/*---------------------------------------------------------------------------*/
static struct backlight t024f754_qvga_cmd_backlight = {
	1, 1, 4095, 100, 1, "PMIC_8941"
};

#define T024F754_QVGA_CMD_SIGNATURE 0xFFFF

#endif /* _PANEL_T024F754_QVGA_SPI_CMD_H_ */



