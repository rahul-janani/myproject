/* Copyright (c) 2017, The Linux Foundation. All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are
* met:
*    * Redistributions of source code must retain the above copyright
*      notice, this list of conditions and the following disclaimer.
*    * Redistributions in binary form must reproduce the above
*      copyright notice, this list of conditions and the following
*      disclaimer in the documentation and/or other materials provided
*      with the distribution.
*    * Neither the name of The Linux Foundation nor the names of its
*      contributors may be used to endorse or promote products derived
*      from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
* ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
* BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
* IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _PANEL_QTB2D4178_QVGA_SPI_CMD_H_
#define _PANEL_QTB2D4178_QVGA_SPI_CMD_H_
/*---------------------------------------------------------------------------*/
/* HEADER files                                                              */
/*---------------------------------------------------------------------------*/
#include "panel.h"

/*---------------------------------------------------------------------------*/
/* Panel configuration                                                       */
/*---------------------------------------------------------------------------*/
static struct panel_config qtb2d4178_qvga_cmd_panel_data = {
	"qcom,mdss_spi_qtb2d4178_qvga_cmd", "spi:0:", "qcom,mdss-spi-panel",
	10, 0, "DISPLAY_1", 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/*---------------------------------------------------------------------------*/
/* Panel resolution                                                          */
/*---------------------------------------------------------------------------*/
static struct panel_resolution qtb2d4178_qvga_cmd_panel_res = {
	240, 320, 79, 59, 60, 0, 10, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/*---------------------------------------------------------------------------*/
/* Panel color information                                                   */
/*---------------------------------------------------------------------------*/
static struct color_info qtb2d4178_qvga_cmd_color = {
	16, 0, 0xff, 0, 0, 0
};



/*---------------------------------------------------------------------------*/
/* Panel on/off command information                                          */
/*---------------------------------------------------------------------------*/

static char qtb2d4178_qvga_cmd_on_cmd1[] = {0x36,0x00};
static char qtb2d4178_qvga_cmd_on_cmd2[] = {0x3a,0x05};
static char qtb2d4178_qvga_cmd_on_cmd3[] = {0x2A,0x00,0x00,0x00,0xEF};
static char qtb2d4178_qvga_cmd_on_cmd4[] = {0x2B,0x00,0x00,0x01,0x3F};
static char qtb2d4178_qvga_cmd_on_cmd5[] = {0xb2,0x0c,0x0c,0x00,0x33,0x33};
static char qtb2d4178_qvga_cmd_on_cmd6[] = {0xb7,0x35};
static char qtb2d4178_qvga_cmd_on_cmd7[] = {0xbb,0x35};
static char qtb2d4178_qvga_cmd_on_cmd8[] = {0xc0,0x2c};
static char qtb2d4178_qvga_cmd_on_cmd9[] = {0xc2,0x01};
static char qtb2d4178_qvga_cmd_on_cmd10[] = {0xc3,0x0b};
static char qtb2d4178_qvga_cmd_on_cmd11[] = {0xc4,0x20};
static char qtb2d4178_qvga_cmd_on_cmd12[] = {0xc6,0x0f};
static char qtb2d4178_qvga_cmd_on_cmd13[] = {0xd0,0xa4,0xa1};
static char qtb2d4178_qvga_cmd_on_cmd14[] = {0xe0,0xd0,0x00,0x02,0x07,0x0b,0x1a,0x31,0x54,0x40,0x29,0x12,0x12,0x12,0x17};
static char qtb2d4178_qvga_cmd_on_cmd15[] = {0xe1,0xd0,0x00,0x02,0x07,0x05,0x25,0x2d,0x44,0x45,0x1c,0x18,0x16,0x1c,0x1d};
static char qtb2d4178_qvga_cmd_on_cmd16[] = {0x35,0x00};
static char qtb2d4178_qvga_cmd_on_cmd16_2[] = {0x44,0x00,0x06};
static char qtb2d4178_qvga_cmd_on_cmd0[] = {0x11};
static char qtb2d4178_qvga_cmd_on_cmd17[] = {0x29};
static char qtb2d4178_qvga_cmd_on_cmd18[] = {0x2C};

static struct mdss_spi_cmd qtb2d4178_qvga_cmd_on_command[] = {
	{sizeof(qtb2d4178_qvga_cmd_on_cmd1), qtb2d4178_qvga_cmd_on_cmd1, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd2), qtb2d4178_qvga_cmd_on_cmd2, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd3), qtb2d4178_qvga_cmd_on_cmd3, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd4), qtb2d4178_qvga_cmd_on_cmd4, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd5), qtb2d4178_qvga_cmd_on_cmd5, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd6), qtb2d4178_qvga_cmd_on_cmd6, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd7), qtb2d4178_qvga_cmd_on_cmd7, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd8), qtb2d4178_qvga_cmd_on_cmd8, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd9), qtb2d4178_qvga_cmd_on_cmd9, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd10), qtb2d4178_qvga_cmd_on_cmd10, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd11), qtb2d4178_qvga_cmd_on_cmd11, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd12), qtb2d4178_qvga_cmd_on_cmd12, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd13), qtb2d4178_qvga_cmd_on_cmd13, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd14), qtb2d4178_qvga_cmd_on_cmd14, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd15), qtb2d4178_qvga_cmd_on_cmd15, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd16), qtb2d4178_qvga_cmd_on_cmd16, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd16_2), qtb2d4178_qvga_cmd_on_cmd16_2, 0x00, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd0), qtb2d4178_qvga_cmd_on_cmd0, 0x78, 0},   //add a delay to fix blurred screen when boot 20170527
	{sizeof(qtb2d4178_qvga_cmd_on_cmd17), qtb2d4178_qvga_cmd_on_cmd17, 0x14, 0},
	{sizeof(qtb2d4178_qvga_cmd_on_cmd18), qtb2d4178_qvga_cmd_on_cmd18, 0x00, 0},

};

#define QTB2D4178_QVGA_CMD_ON_COMMAND 20


static char qtb2d4178_qvga_cmdoff_cmd0[] = {
	0x28,
};

static char qtb2d4178_qvga_cmdoff_cmd1[] = {
	0x10,
};

static struct mipi_dsi_cmd qtb2d4178_qvga_cmd_off_command[] = {
	{0x1, qtb2d4178_qvga_cmdoff_cmd0, 0x20},
	{0x1, qtb2d4178_qvga_cmdoff_cmd1, 0x20}
};

#define qtb2d4178_QVGA_CMD_OFF_COMMAND 2

/*---------------------------------------------------------------------------*/
/* Panel reset sequence                                                      */
/*---------------------------------------------------------------------------*/
static struct panel_reset_sequence qtb2d4178_qvga_cmd_reset_seq = {
	{1, 0, 1, }, {20, 2, 20, }, 2
};

/*---------------------------------------------------------------------------*/
/* Backlight setting                                                         */
/*---------------------------------------------------------------------------*/
static struct backlight qtb2d4178_qvga_cmd_backlight = {
	1, 1, 4095, 100, 1, "PMIC_8941"
};

#define qtb2d4178_QVGA_CMD_SIGNATURE 0xFFFF

#endif /* PANEL_qtb2d4178_QVGA_SPI_CMD_H */
