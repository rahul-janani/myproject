#include <stdio.h>

int main()
{

	unsigned int x= 0x11223344;
	int i;
        char *ptr;
	ptr=(char*)&x;

	for(i=0;i<4;i++)
	{
		printf("byte: %x \t address:%p\n",ptr[i],&ptr[i]);
	}
	return 0;    
}

