#include <stdio.h>

union endianness
{
unsigned int val;
char r;
};

int main()
{
	union endianness endian;
	endian.val=0x1;

	if(endian.val==1)
		puts("littile endian");
	else
		puts("big endian");
	 
	return 0;
}
