#include "xtest_test.h"
#include "xtest_helpers.h"

#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>


#include <signed_hdr.h>
#include <util.h>

#include <ta_testcase.h> 

//#ifdef CFG_SECSTOR_TA_MGMT_PTA
//#include <pta_secstor_ta_mgmt.h>
//#endif



# if 1
static void xtest_tee_test_1020(ADBG_Case_t *c)
{
	//TEEC_Result res;
	TEEC_Session session = { 0 };
	TEEC_Operation op = TEEC_OPERATION_INITIALIZER;
	uint32_t ret_orig;

	

	if (!ADBG_EXPECT_TEEC_SUCCESS(c,xtest_teec_open_session(&session, &testcase_ta_uuid, NULL,
					      &ret_orig)))
	{
		Do_ADBG_Log(" - 1020 -   skip test, janani TA not found");
				return;
	}

	//res = xtest_teec_open_session(&session, &testcase_ta_uuid, NULL,
				     // &ret_orig);
	//if (res == TEEC_ERROR_ITEM_NOT_FOUND) {
		//Do_ADBG_Log(" - 1020 -   skip test, janani TA not found");
		//return;
	//}
		else
		 {
			Do_ADBG_Log(" - 1020 -   entered in to janani test case");
		 }
	op.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_NONE,
					 TEEC_NONE);

	(void)ADBG_EXPECT_TEEC_SUCCESS(c,
		TEEC_InvokeCommand(&session,TA_INVOKE_TESTS_CMD, &op,
				   &ret_orig));
	
	TEEC_CloseSession(&session);
}
ADBG_CASE_DEFINE(regression, 1020, xtest_tee_test_1020, "janani test case");

#endif


