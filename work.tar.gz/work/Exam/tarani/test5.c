﻿#include <string.h>
#include <stdio.h>
void convertStrings(char *line,int ch);
void removeChar(char *str);

int main()
{
	    char str[50]="hello this is new world";
	    char ch;
	    int i,j;
	    printf("%s\n", str);
	    for(i=0;i<5;i++)
	    {
		    //while(str[i]=="")
			    str[i]=str[i]-32;
	    }
	    str[6]=str[6]-32;
	    for(i=11;i<=12;i++)
		    str[i]=str[i]-32;
	    str[14]=str[14]-32;
	    for(i=18;str[i]!='\0';i++)
		    str[i]=str[i]-32;
	    printf("after modifying %s\n",str);

			

	    printf("enter a character to be removed\n");
	    scanf("%c",&ch);
	    convertStrings(str,ch);
	    printf("after removing :%s\n",str);
}
void convertStrings(char *line,int ch)
{
	int i;
	for(i=0;line[i] !='\0';i++)
	{
		if(line[i]==ch)
			removeChar(&(line[i]));
	}
}

void removeChar(char *str)
{
	    int i=0;
	    while(str[i]!='\0')
	    {
		    str[i]=str[i+1];
		    i++;
	    }
}
