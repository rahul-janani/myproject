#include<stdio.h>
int main()
{
	int n,a,b,sum=0,m;
	//printf("enter a 2 digit number\n");
	//scanf("%d",&n);
	for(n=10;n<100;n++)
	{
		m=n;
	a=n%10;
	b=n/10;
//	printf("sum %d\n",sum);
	if(m==(3*(a+b)))
		printf("%d\n",m);
	}
}


