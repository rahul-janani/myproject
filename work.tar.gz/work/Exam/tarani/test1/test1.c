#include<stdio.h>
int main()
{
	int arr[50]={43,65,51,27,79,11,56,61,82,9,25,36,7,49,55,63,74,81,49,37,40,49,16,75,87,91,33,24,58,78,65,56,76,67,45,54,36,63,12,21,74,9,51,19,39,49,68,93,85,59};
	int i,a;
	for(i=0;i<50;i++)
	{
		printf("%d\t",arr[i]);
	}
	for(i=0;i<50;i++)
	{
		if(arr[i]>80)
			printf("pass:%d\n",arr[i]);
		else if(arr[i]<80 && arr[i]>=37)
		{
			if(arr[i]%5!=0)
			{
				//a=arr[i];
				//while(arr[i]%5==0)
					arr[i]=(arr[i]+(5-arr[i]%5));
				printf("pass but rounding off :%d\n",arr[i]);
			}
			else
			{
				printf("pass no need of rounding off :%d\n",arr[i]);
			}
		}
		else if(arr[i]<37)
		{
			if((37-arr[i])>5)
			{
				if(arr[i]%5!=0)
				{
					//while(arr[i]%5==0)
					//	arr[i]++;
					arr[i]=(arr[i]+(5-arr[i]%5));

					printf("fail but rounding off :%d\n",arr[i]);
				}
				else
					printf("fail no need of rounding off :%d\n",arr[i]);
			}
			else
				printf("fail should not round off :%d\n",arr[i]);
		}
	}

}



