#include<stdio.h>
#include<stdlib.h>
void main()
{
freopen("test3.txt","r",stdin);
char arr[100],ch;
int i;
printf("enter string and charecter ch\n");
gets(arr);
scanf("%c",&ch);
printf("entered charector is %c \n",ch);
printf("before removing given charecter in string is %s\n",arr);
i=0;
while(arr[i]!='\0')
{
if(arr[i]==ch)
{
arr[i]=' ';
}
else
arr[i]=arr[i];
i++;
}
//printf("after removing given charecter in string is %s\n",arr);
puts(arr);
}
