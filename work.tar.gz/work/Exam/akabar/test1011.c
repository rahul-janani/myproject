#include<stdio.h>
#include<stdlib.h>
void main()
{
	int x,y;
	for(x=1;x<10;x++)
	{
		for(y=1;y<10;y++)
		{
			if((7*x)==(2*y))
			{
				printf("the number is %d\n",(10*x)+y);
			}
		}
	}
}
