#include "header.h"
int main()
{
freopen("/home/pandirah/Exam/usha/31-08-2018/input.txt","r", stdin);

int n,sum=0,rem,temp;
//printf("Enter any two digit number:");
scanf("%d",&n);
for(temp=n;temp>0;temp=temp/10)
{
rem=temp%10;
sum=sum+rem;
}
if(n==(sum*3))
printf("\nIts a Peculiar two digit number");
else
printf("\nNot a Peculiar two digit number");
return 0;
}
