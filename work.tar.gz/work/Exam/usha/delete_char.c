#include<stdio.h>
#include<string.h>

#define MAX 100
void del(char str[], char ch);
void main()
{

   char str[MAX];
   char ch;
 
   printf("\nEnter the string : ");
   fgets(str, MAX, stdin);
   printf("string is: %s\n", str);
 
   printf("\nEnter character which you want to delete : ");
   scanf("%ch", &ch);
   del(str, ch);
}
 
void del(char str[], char ch) {
   int i, j = 0;
   int size;
   char ch1;
   char str1[10];
 
   size = strlen(str);
 
   for (i = 0; i < size; i++) {
      if (str[i] != ch) {
         ch1 = str[i];
         str1[j] = ch1;
         j++;
      }
   }
   str1[j] = '\0';
 
   printf("\ncorrected string is : %s", str1);
}
