/*ASSUMPTIONS: for the code*/
/*2 digit number will start from 11 to 99*/

#include<stdio.h>
#include<stdlib.h>

#define START_TWODIGIT_NUMBER 11
#define END_TWODIGIT_NUMBER 99

int main()
{
int sum,temp,temp1;
sum=0;
temp=0;
temp1=0;

for(int i=START_TWODIGIT_NUMBER;i<=END_TWODIGIT_NUMBER;i++)
{
	temp1=i;
	temp = (temp1%10);
	temp1=temp1/10;
	sum = (temp+temp1);

	if(i == (3*(sum)))
	{
		printf("\n num:%d",i);
	}

}

}
