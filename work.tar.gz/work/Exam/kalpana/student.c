#include<stdio.h>
#include<string.h>                                  
#define MAXVAL 50
int main()
{
	int  value [MAXVAL]={43,65,51,27,79,11,56,61,82,9,25,36,7,49,55,63,74,81,49,37,40,49,16,75,87,91,33,24,58,78,65,56,76,67,45,54,36,63,12,21,74,9,51,19,39,49,68,93,85,59} ,temp_val[MAXVAL];
	int i ;


	printf("enter 50 students marks\n");
	//for (i = 0; i < MAXVAL; i++)
	//{

		//scanf ("%d", &value [i]) ;
	//}

	for(i=0;i<MAXVAL;i++)
	{

		if(value[i]>37)
		{

			printf("fail %d\n",i);
			i++;
		}
		if (value[i]>80)
		{
		printf("dont do any changes\n");
		}
		else
		{
		if((value[i]%5))
		{
			temp_val[i]=value[i]+(5-((value[i])%5));
			printf(" %d member value changed to %d\n",i,temp_val[i]);
		}
		}

	}



}
