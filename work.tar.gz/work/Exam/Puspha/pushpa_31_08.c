//write c program to find a peculiar two digit number which is three times the sum of its digits.

#include<stdio.h>
#include<stdlib.h>
int main()
{
	int num,num2,cnt=0,digit=0,sum=0;
	printf("enter any two digit no\n");
	scanf("%d",&num);
	num2=num;
	while(num2)
	{
		cnt++;
		num2=num2/10;
	}
	if(cnt>2)
	{
		printf("error enter two digit no only\n");
		
	}
	num2=num;

	while(num2)
	{
		digit=num2%10;
		sum=sum+digit;
		num2=num2/10;
	}
	if((sum*3)==num)
	{
		printf("%d is peculier no\n",num);
	}
	else
	{
		printf("%d is not peculeir no\n",num);
	}
}



