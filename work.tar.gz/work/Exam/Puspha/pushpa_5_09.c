/*program to modify the below string.

1.

Input: hello this is new world
output: HELLO This IS New WORLD

2. Remove given character from string

*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
 char * modify_str(char *str);
char * remove_char(char *);
int main()
{
char  str[100],*p;
printf("enter string\n");
gets(str);
p=modify_str(str);
printf("%s",p);
p=remove_char(str);
printf("%s",p);
}
 char * modify_str(char *str)
{
char * p;
int i,j;int cnt=0,cnt1=0;
for(i=0;str[i];i++)
{
if(str[i]==' ')
++cnt;
if(cnt/2==0)
{
if((str[i]>='a')&&(str[i]<='z'))
{
str[i]=str[i]-32;
}
}
else
{
++cnt1;
if((str[i]>='a')&&(str[i]<='z'))
{
str[i]=str[i]-32;
}
if(cnt1==1)
continue;
}
}
return str;
}
char * remove_char(char* str)
{
char *p;int ch;
int i,j;
printf("\nentr char u wanna remove\n");
scanf("%c",ch);
p=str;
while(*p)
{
if(p=strchr(p,ch))
{
memmove(p,p+1,strlen(p+1)+1);
}
p=p+1;
}
return str;

}
