/*Given below is the list of marks obtained by a class of 50 students in an annual examination.
  43 65 51 27 79 11 56 61 82 09 25 36 07 49 55 63 74 81 49 37 40 49 16 75 87 91 33 24 58 78 65
  56 76 67 45 54 36 63 12 21 73 49 51 19 39 49 68 93 85 59
  pass marks: 37

  write a program to round up obtain marks if person get above 80 no round up to done.

  if person get not a multiple of 5 round there's marks to 5 multiple.

  if person fails and difference between passing marks is less than 5 round up passing marks else no round up is require
 */

#include<stdio.h>
#include<stdlib.h>
int main()
{
	int stud_data[50]={43, 65, 51, 27, 79, 11, 56, 61, 82,9 ,25, 36, 7, 49, 55, 63, 74, 81, 49, 37, 40, 49, 16, 75, 87, 91, 33, 24, 58, 78, 65,	56, 76, 67, 45, 54, 36, 63, 12, 21, 73, 49, 51, 19, 39, 49, 68, 93, 85, 59};
	int pass_marks=37;
	int i,j;
	////////for printing
	printf("\nbefore rounding off\n");
	for(i=0;i<50;i++)
	{
		printf("%d\t",stud_data[i]);
	}
	/////////////////////
	for(i=0;i<50;i++)
	{
		if(stud_data[i]>80)
		{
			printf("\nno round up needed %d\n",stud_data[i]);
		}
		else if(stud_data[i]>pass_marks)
		{
			if((stud_data[i]%5)!=0)
			{
				stud_data[i]=(stud_data[i]/5)*5;
			}
		}
		else
		{
			if((pass_marks-stud_data[i])<5)
			{
				stud_data[i]=pass_marks;
			}
		}
	}

	////////for printing
	printf("\naftr rounding off\n");
	for(i=0;i<50;i++)
	{
		printf("%d\t",stud_data[i]);
	}
	/////////////////////
}

