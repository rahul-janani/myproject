/*program to Implement stack using linked list and validate expression is correct or not

Ex:  {()()} this expression is correct
{()()}) this expression is in correct*/

#include<stdio.h>
#include<stdlib.h>
struct node
{
int  data;
	struct node *link;
};
struct node * top=NULL;
void push()
{
	struct node * temp;
	temp=(struct node *)malloc(sizeof(struct node));
//	fflush(stdin);
	printf("entr data\n");
//temp->data=getchar();
	scanf("%d",&temp->data);
	temp->link=top;
	top=temp;
}
void pop()
{
	struct node * temp;
	if(top==NULL)
	{
		printf("no node is present\n");
		return;
	}
	else
	{
		temp=top;
		printf("%d delete\n",temp->data);
		top=temp->link;
		temp->link=NULL;
		free(temp);
	}
}
void traverse()
{
	struct node * temp;

	if(top==NULL)
	{
		printf("stack is empty\n");
		return;
	}
	temp=top;
	while(temp)
	{
		printf("%d\n",temp->data);
		temp=temp->link;
	}
}


int main()
{
	while(1)
	{int ch;
		printf("1. insert  2. delete 3. exit 4. traverse\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: push(); break;
			case 2: pop(); break;
			case 3: exit(0);
			case 4: traverse();break;
			default:printf("invalid input:\n");
		}
	}
}

