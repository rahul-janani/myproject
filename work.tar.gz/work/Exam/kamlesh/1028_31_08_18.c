#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int sum_dgt( int num )
{
      int temp,sum=0,rem;
       temp =num;
while(temp)
  {
//rem=temp%10;
  sum=sum+temp%10;
  temp=temp/10;
  }

return sum;
}

int main()
{

  int i,rem,temp,sum=0;
  for(i=10;i<99;i++)
  {
if(i==(sum_dgt(i)*3))
printf("***%d\n",i);
  
  }
  




}
