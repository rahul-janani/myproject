#include<stdio.h>
#include<stdlib.h>

#define pass_mark 37
int arr[50]={43,65,51,27,79,11,56,61,82,9,25,36,7,49,55,63,74,81,49,37,40,49,16,75,87,91,33,24,58,78,65,56,76,67,45,54,36,63,12,21,73,49,51,19,39,49,68,93,85,59,};

int round_of_5(int num)
{
  int rem,result;
  rem=num%5;
  result=num+(5-rem);
  return result;

}

int main()
{
  int i;
  while(i!=50)
  {
    if(arr[i]<80 && arr[i] >37 && arr[i]%5!=0){
      arr[i]=round_of_5(arr[i]);
    }
     if(arr[i]<37 && (round_of_5(arr[i])-arr[i]<5))
      arr[i]=round_of_5(arr[i]);


  printf("%d ",arr[i]);
    i++;
  }

}

