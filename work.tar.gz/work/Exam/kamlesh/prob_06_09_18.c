#include<stdio.h>
#include<stdlib.h>

struct Node
{
char ch;
  struct Node *next;
}*top = NULL;

void push(char );
char pop();
void check(void);
void display();

void main()
{
  int choice;
 char sym;
 
  while(1){
    printf("\n****** MENU ******\n");
    printf("1. Push\n2. Pop\n3. Display\n4. Exit\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);
    switch(choice){
      case 1: printf("Enter the character  ");
             scanf(" %c",&sym);
              push(sym);
              break;
     // case 2: pop(); break;
      case 2: check(); break;
      case 3: display(); break;
      case 4: exit(0);
      default: printf("\nWrong \n");
    }
  }
}
void push(char value)
{
  struct Node *newNode;
  newNode = (struct Node*)malloc(sizeof(struct Node));
  newNode->ch= value;
  if(top == NULL)
    newNode->next = NULL;
  else
    newNode->next = top;
  top = newNode;
}


void check(void)
{

char ch[10];
int i=0;

 ch[i++]= pop();

//f(i>1)
//validate(char ch[]);
}
/*
void validate(char ch[])
{
  int i;
  for(i=0;
  
}*/
char pop()
{
  char data;

  if(top == NULL)
    printf("\nStack is Empty\n");
  else{
    struct Node *temp = top;
data=temp->ch;
//  printf("\nDeleted element: %c", temp->ch);
    top = temp->next;
    free(temp);
  return data;
  }
}
void display()
{
char data;
  if(top == NULL)
    printf("\nStack is Empty\n");
  else{
    struct Node *temp = top;
    while(temp->next != NULL){
      printf("%c--->",temp->ch);
      data=temp->ch;

     temp = temp -> next;
    if(temp->next==NULL)
    {
    if(temp->ch==pop())
    printf("check %c,%c ",temp->ch,pop());
    printf("nook %c,%c ",temp->ch,pop());
    }
    }
    printf("%c--->NULL",temp->ch);
  }

}    



