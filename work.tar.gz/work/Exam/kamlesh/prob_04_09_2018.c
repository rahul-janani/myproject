#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#define a 32

void remo(char *str)
{
  char ch;
  int i=0,j;
  printf("\nenter character to remove\n");
  scanf("%c",&ch);
  while(str[i]){
    if(str[i]==ch)
    {
      for(j=i;str[j];j++)
        str[j]=str[j+1];

      str[j]='\0';
    }

    i++;
  }


  printf("%s",str);
}



int main()
{
  char str[50]="hello this is new world";
  int i,j=0,flag=0,cnt=0;

  printf("%s\n",str);

  for(i=0;str[i];i++)
  {
  

    if(str[i]==' ')
    {
      i++;
      str[i]=str[i]-32;

    }
    


    while(str[j]!=' '){

      str[j]= str[j]-32;
      j++;
    }

      }

    

    printf("%s",str);
    remo(str);

  }

  
