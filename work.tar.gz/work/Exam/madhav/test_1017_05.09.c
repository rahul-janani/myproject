#include<stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{

	char ch[]="hello this is new world";
	int len,count=0,i=0,j=0,flag=0;
	char c;
	while(ch[i])
	{
		if(ch[i]==' ' && ch[i++]!=' ')
		{
			count++;
			i++;
			continue;
		}

		if(count%2==0)
			ch[i]=ch[i]-32;
		else if(count%2!=0 && ch[i--]==' ')
			ch[i]==ch[i]-32;
		i++;
	}
	printf("after change %s\n",ch);
	printf("enter the character to delete for string\n");
	scanf("%c",&c);
			
	while(ch[j])
	{
		if(ch[j]==c)
		{
			while(ch[j])
			ch[j]=ch[j++];
			flag==1;

			break;
		}
		
	}
	if(flag==0)
		printf("entered character is not matched\n");
	else
		printf("after delete char %s\n",ch);
	return 0;
}
