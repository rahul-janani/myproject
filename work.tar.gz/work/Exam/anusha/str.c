#include<stdio.h>
#include<string.h>
main()
{
int i;
char c,str1[19],str[]="hello this is new world";
//for(i=0;str[i]!='\0';i++)
//str[i]=str[i]-32;
printf("%s\n",str);
printf("enter the charector\n");
scanf(" %c",&c);
for(i=0;str[i]!='\0';i++)
{if(str[i]==c)
	    while(str[i]!='\0')
	    {
		    str[i]=str[i+1];
		    i++;
	    }
}
printf("%s",str);
}

