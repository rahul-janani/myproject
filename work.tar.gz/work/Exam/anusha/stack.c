#include <stdio.h>
#include <stdlib.h>
 
struct node
{
    char info;
    struct node *ptr;
}*top,*top1,*temp=NULL;
void push(char data);
void pop();
int count = 0;
main()
{
int ch;
char s;
printf("\n 1 - Push");
printf("\n 2 - Pop\n");
while(1)
{
printf("enter ur choice\n");
scanf("%d",&ch);
switch (ch)
        {
        case 1:
            printf("Enter data :\n");
            scanf(" %c", &s);
            push(s);
            break;
        case 2:
            pop();
            break;
	default :
            printf(" Wrong choice, Please enter correct choice \n");
}
}
}
void push(char data)
{
    if (top == NULL)
    {
        top =(struct node *)malloc(1*sizeof(struct node));
        top->ptr = NULL;
        top->info = data;
    }
    else
    {
        temp =(struct node *)malloc(1*sizeof(struct node));
        temp->ptr = top;
        temp->info = data;
        top = temp;
    }
    count++;
}
void pop()
{
    top1 = top;
 
    if (top1 == NULL)
    {
        printf("\n Error : Trying to pop from empty stack");
        return;
    }
    else
        top1 = top1->ptr;
    printf("\n Popped value : %c\n", top->info);
    free(top);
    top = top1;
    count--;
}
