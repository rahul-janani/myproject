#include<stdio.h>
main()
{
int n,i,r,sum=0,a;
for(i=10;i<100;i++)
{
n=i;
//while(n!=0)
{
  r=n%10;
  a=n/10;

}
if(i==3*(a+r))
  printf("%d is peculiar\n",n);
  //else
  //printf("not peculiar\n");
  }
}
