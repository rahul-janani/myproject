#include<stdio.h>
#include<string.h>
int main()
{
	char str[50]="hello this is new world";
	int size=sizeof(str);
	int i;
	char temp;
	//fgets(str,size,stdin);
	for(i=0;str[i]!='\0';i++)
	{
		str[i]=str[i]-32;
	//printf("%c\n",str[i]);
	}
	printf("after converting lower to upper case:::%s\n",str);
	fputs(str,stdout);

	printf("enter a string\n");
	scanf("%c",&temp);



	for(i=0;str[i]!='\0';i++)
	{
		if(temp==str[i])
		{
			str[i]=str[++i];
		}	
	}
	printf("after removing of given charter:::%s",str);
}
