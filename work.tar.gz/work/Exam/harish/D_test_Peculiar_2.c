#include<stdio.h>
int main()
{
	int num,sum_dig=0,temp,rem;
	while(1)
	{
		printf("enter two digit number\n");
		scanf("%d",&num);
		temp=num;

		while(temp)
		{
		rem=temp%10;
		sum_dig=sum_dig+rem;
		temp=temp/10;
		} 
	
		if(num==(3*sum_dig))
		{
		printf("The given number is peculiar number::%d\n",num);
		}
		else
		printf("The given number is not peculiar number::%d\n",num);
		sum_dig=0;
	}	
	return 0;
}

//ex:input 27 is peculiar number	27=3*(2+7)=27
