#include<stdio.h>
int main()
{
	int i;
	for(i=10;i<100;i++)
	{
		if(i==3*(i/10+i%10))
			printf("%d ",i);
	}
}
