#include<stdio.h>
int main()
{
	char ch,str[]="hello this is new world";
	int i,sp=1;
	printf("Old string:%s\n",str);
	for(i=0;str[i];i++)
	{
		if(str[i]==' '){
			sp++;
			str[++i]-=32;
			continue;
		}
		if(sp%2!=0)
		{	
			str[i]=str[i]-32;
		}
	}
	printf("New String:%s\n",str);
	printf("Enter a character to Remove from String:");
	scanf("%c",&ch);
	for(i=0;str[i];i++)
	{
		if(str[i]==ch)
		{
			str[i]=' ';
		}
	}
	printf("New String is:%s\n",str);
}
