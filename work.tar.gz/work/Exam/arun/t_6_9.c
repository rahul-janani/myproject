
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
 

struct Stack
{
    char data;
    struct Stack* next;
};
 
struct Stack* newNode(char data)
{
    struct Stack* stackNode =
              (struct Stack*) malloc(sizeof(struct Stack));
    stackNode->data = data;
    stackNode->next = NULL;
    return stackNode;
}
 
int isEmpty(struct Stack *root)
{
    return !root;
}
 
void push(struct Stack** root, char data)
{
    struct Stack* stackNode = newNode(data);
    stackNode->next = *root;
    *root = stackNode;
    printf("%c pushed to stack\n", data);
}
 
int pop(struct Stack** root)
{
    if (isEmpty(*root))
        return INT_MIN;
    struct Stack* temp = *root;
    *root = (*root)->next;
    int popped = temp->data;
    free(temp);
 
    return popped;
}
int check(struct Stack **root ,char * str,int n)
{
	int i;
	struct Stack * trav=*root;
//	printf("%d",n);
	for(i=n-1;i>=0;i--){
		if(str[i]!=trav->data)
			return 0;
//		printf("%c",trav->data);
		trav=trav->next;
	}
	return 1;
}

int main()
{
    struct Stack* root = NULL;
	char str[50]; 
	int len;
    push(&root, '{');
    push(&root, '(');
    push(&root, ')');
    push(&root, '(');
    push(&root, ')');
    push(&root, '}');

    printf("Enter the expression to check:");
    scanf("%s",str);
    len=strlen(str);
 	if(check(&root,str,len))
		printf("Correct");
	else
		printf("Incorrect");
    return 0;
}
