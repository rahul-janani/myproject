#include<stdio.h>

int main()
{
	freopen("tfile","r",stdin);
	int marks[50],i;
	for(i=0;i<50;i++)
	{
		scanf("%d",&marks[i]);
		
		if(marks[i]<37 && 37-marks[i]<5)
				continue;
		if(marks[i]%5!=0)
			marks[i]=marks[i]+(5-marks[i]%5);
	}
	for(i=0;i<50;i++)
	{
		printf("%d ",marks[i]);
	}

}
