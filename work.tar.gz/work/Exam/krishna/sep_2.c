#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/*
void delchar(char *x,int a, int b)
{
  if ((a+b-1) <= strlen(x))
  {
    strcpy(&x[b-1],&x[a+b-1]);
    puts(x);
    }
}*/
void remchar( char str1[], char ch)
{
int i;
    for(i = 0; str1[i] != '\0'; i++)   //start for loop
    {
         
    if(str1[i] == ch)     //test for character
            {
            str1[i] = str1[i] + 1 ; // write next character back to current position
            }
        }
}
    
int main()
{
   	char str[200]="hello this is new world";
 	char str1[200];
   	int i,pos,n;
	char ch;
	strcpy(str1,str);
	printf("enter the character you want to delete");
	scanf("%c",&ch);
    	//printf("Enter the position from where you want to delete:");
     	//scanf("%d",&pos);
     	//printf("Enter the number of characters to be deleted :");
    	 //scanf("%d",&n);
    	 //delchar(str1, n,pos);
	remchar(str1,ch);
	printf("\nstring after removing character is\t:>%s\n", str1);       //string post call
 
    	for(i=0;i<=strlen(str);i++)
    	{
        if(str[i]>=65&&str[i]<=90)
        str[i]=str[i]+32;
    	}
    	printf("String in Lowercase: %s",str);
    	/* To print string in upperCase*/
    	for(i=0;i<=strlen(str);i++)
    	{
        if(str[i]>=97&&str[i]<=122)
            str[i]=str[i]-32;
    	}
    	printf("\n\nString in Uppercase: %s\n",str);

    
    return 0;
}
