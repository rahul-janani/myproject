#include<stdio.h>

int main()
{
	int arr[50]={43,65,51,27,79,11,56,61,82,9,25,36,7,49,55,63,74,81,49,37,40,49,16,75,87,91,33,24,58,78,65,56,76,67,45,54,36,63,12,21,74,9,51,19,39,49,68,93,85,59},marks,new_marks, passing_marks=37;
	printf("enter the marks obtained\n");
	
	//scanf("%d",&marks);
	//printf("passing marks is 37\n");
	
	if (marks>80)
	{
		printf("No round off done,marks is %d",marks);
	}
	else if(marks%5!=0)
	{
		new_marks=5*marks;	
		printf("your marks is rounded to multiple of 5, new marks is %d",new_marks);
	}
	else if(marks<37)
	{
		if((passing_marks - marks)> 5)
		{
			new_marks=marks;
			printf("your marks is %d", new_marks);
		}
		else
		{
			new_marks=37;
			printf("your marks is rounded to passing marks %d",new_marks);
		}
	}
}
