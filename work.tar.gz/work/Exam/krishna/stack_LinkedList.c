#include<stdio.h>
#include<stdlib.h>

struct node{
	int data;
	struct node *next;
};
struct node *top=NULL;

void push(int);
void pop();
void display();

int main()
{
	int ch,item;
	while(1)
	{
	printf("********Stack Operation*********\n");
	printf("Enter your option: ");
	printf("1.Push\n2.Pop\n3.Display\n");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1: printf("enter the number to be pushed\n");
			scanf("%d",&item);
			push(item);
			break;
		case 2: pop();
			break;
		case 3: display();
			break;
		default:
			printf("Invalid Option\n");

	}
	}
}

void push(int item)
{
	struct node *newNode;
	newNode=(struct node*)malloc(sizeof(struct node));
	newNode->data=item;
	if(top==NULL)
	{
		printf("stack is Empty\n");
		newNode->next=NULL;
	}
	else
	{
		newNode->next=top;
	}
		top=newNode;
		printf("Insertion Successful\n");
}

void pop()
{
	if(top==NULL)
	{
		printf("Deletion not possible\n");
	}
	else
	{
		struct node *temp=top;
		printf("Deleted element is %d",temp->data);
		top=temp->next;
		free(temp);
	}
}

void display()
{
	
	if(top==NULL)
	{
		printf("stack is empty\n");
	}
	else
	{
	struct node *temp=top;
	while(temp->next!=NULL)
	{
		printf("%d",temp->data);
		temp=temp->next;
	}
	printf("%d",temp->data);
	}
}

