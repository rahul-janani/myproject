#include<stdio.h>

int main()
{
int x = 0;
int y = 0;

for(x = 1; x < 10; x++)
{
	for (y = 1; y < 10; y++)
	{
		if( (7 * x ) == (2 * y))
		{
			printf("two digit no is %d", ((10 * x) + y));
		}
	}
	}

return 0;
}

