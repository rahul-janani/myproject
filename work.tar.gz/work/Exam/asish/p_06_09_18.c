#include<stdio.h>
#include<stdlib.h>
typedef struct stack{
	char data;
	struct stack *next;
}node;

node *head = NULL;

int isempty(void)
{
  if(head == NULL) 
	return 1;
  else
	return 0;
}

void push(char item)
{
 node *new = NULL;
 new = malloc(sizeof(node)); 
 if(new == NULL) { 
	printf("Stack is full!!!\n");
	return;
 }

 
 new->data = item; 
 new->next = head;
 head =  new;
}

char pull(void)
{
  
  char item;
  node *temp;
  if(isempty()) {
	printf("Stack is empty!!!\n");
	exit(-1);
  }
  item = head->data;
  temp = head;
  head = head->next;
  temp->next = NULL;
  free(temp);		
  return item;	
}
void print()
{
 node *ptr;
 if(head == NULL)
	return;
 ptr = head;
 while(ptr)
 {
	printf("%c-->",ptr->data);
	ptr = ptr->next;
 }
}
int main()
{node *ptr;
 int i;
 char item;
 char test1[] = {'{','(',')','(',')','}'};
 char test2[] = {'{','(',')','(',')','}',')'};	
 for(i = 0;i < sizeof(test1);i++)
 {
	push(test1[i]);
 }

 print();
  ptr = head;
  i = sizeof(test1) - 1;
/* 
 while(ptr){
	item = ptr->data
	if(item == )
  }
*/ 
 
}
