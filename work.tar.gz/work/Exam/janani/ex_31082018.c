#include<stdio.h>

int main()
{
int dig1,dig2,n=10,res;
while(n<100)
{
dig1=n%10;
dig2=n/10;
res=3*(dig1+dig2);
if(n==res)
printf("pecular number:%d\n",n);
n++;
}

return 0;
}
