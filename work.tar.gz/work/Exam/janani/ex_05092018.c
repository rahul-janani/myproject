#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void removeChar(char *str, char garbage);
void modifychar(char str[]);
int main(void) {
    char* str = malloc(strlen("hello this is new world")+1),c;
    char arr[30]="hello-this-is-new-world";
    strcpy(str, "hello this is new world");
    puts("enter character");
    scanf("%c",&c);
    removeChar(str, c);
   // modifychar(arr);
    printf("%s",str);
    free(str);
    return 0;
}
void removeChar(char *str, char garbage) {

    char *src, *dst;
    for (src = dst = str; *src != '\0'; src++) {
        *dst = *src;
        if (*dst != garbage) dst++;
    }
    *dst = '\0';
}

void modifychar(char str[])
{
        printf("string is %s\n", str);
 	char* token = strtok(str, " ");
    while (token != NULL) {
        printf("%s\n", token);
        token = strtok(NULL, "-");
       
    }
    
}



